#!/bin/bash
# Automatic GitHub Pages deploy script for RealNation Rhythms
# Run this after committing changes: npm run deploy

echo "🚀 Building production files..."
npm run build

echo "📦 Deploying to gh-pages branch..."
npx gh-pages -d dist -b gh-pages

echo "✅ Deployment complete! Visit:"
echo "https://biggmanny.github.io/realnation-rhythms/"

# RealNation Rhythms — GitHub Pages (gh-pages branch)

This project is ready for one-command deployment to GitHub Pages.

### 🚀 Deployment Steps

1. Create a new GitHub repo named **realnation-rhythms** under your **biggmanny** account.
2. Upload this project (or `git push` it) to that repo.
3. Run the following commands locally:

```bash
npm install
npm run deploy
```

This will build the site and automatically publish it to the **gh-pages** branch.

Your live site will appear at:
👉 https://biggmanny.github.io/realnation-rhythms/
